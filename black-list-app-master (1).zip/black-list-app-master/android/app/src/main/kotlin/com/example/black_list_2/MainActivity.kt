package com.example.black_list_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
