import 'dart:io';
import 'package:black_list_2/model/comment.dart';
import 'package:black_list_2/model/user_state.dart';
import 'package:black_list_2/model/vehicule.dart';
import 'package:black_list_2/utils/uitilities.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/cupertino.dart';
import 'package:path/path.dart' as Path;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:black_list_2/model/user.dart';

class DBServices {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final CollectionReference usercol =
      FirebaseFirestore.instance.collection("users");
  final CollectionReference carouselcol =
      FirebaseFirestore.instance.collection("carousel");
  final CollectionReference vehiculecol =
      FirebaseFirestore.instance.collection("vehicule");
  final CollectionReference commentcol =
      FirebaseFirestore.instance.collection("commentaires");

  Future saveUser(UserM user) async {
    try {
      await usercol.doc(user.id).set(user.toMap());
      return true;
    } catch (e) {
      return false;
    }
  }

  Future getUser(String id) async {
    try {
      final data = await usercol.doc(id).get();
      final user = UserM.fromJson(data.data());
      return user;
    } catch (e) {
      return false;
    }
  }

  Future<User> get userd async {
    final user = FirebaseAuth.instance.currentUser;
    return user;
  }

  Future<UserM> getUserDetails() async {
    User currentUser = await userd;

    DocumentSnapshot documentSnapshot =
        await usercol.doc(currentUser.uid).get();
    return UserM.fromMap(documentSnapshot.data());
  }

  void setUserState({@required String userId, @required UserState userState}) {
    int stateNum = Utils.stateToNum(userState);
    print("is here now  mmm");
    usercol.doc(userId).update({
      "state": stateNum,
    });
  }

  Future getUser1(String id) async {
    final data = await usercol.doc(id).get();
    final user = UserM.fromJson(data.data());
    return user;
  }

  Future updateUser(UserM user) async {
    try {
      await usercol.doc(user.id).update(user.toMap());
      return true;
    } catch (e) {
      return false;
    }
  }

  Stream<UserM> get getCurrentUser {
    final user = FirebaseAuth.instance.currentUser;
    return user != null
        ? usercol.doc(user.uid).snapshots().map((user) {
            UserM.currentUser = UserM.fromJson(user.data());
            return UserM.fromJson(user.data());
          })
        : null;
  }

  Future<String> uploadImage(File file, {String path}) async {
    var time = DateTime.now().toString();
    var ext = Path.basename(file.path).split(".")[1].toString();
    String image = path + "_" + time + "." + ext;
    try {
      StorageReference ref =
          FirebaseStorage.instance.ref().child(path + "/" + image);
      StorageUploadTask upload = ref.putFile(file);
      await upload.onComplete;
      return await ref.getDownloadURL();
    } catch (e) {
      return null;
    }
  }

  Future<List> get getCarouselImage async {
    try {
      final data = await carouselcol.doc("JhQoJcrV18AEaLmm4bMF").get();
      return data.data()["imgs"];
    } catch (e) {
      return null;
    }
  }

  Future savevehicule(Vehicule vehicule) async {
    try {
      await vehiculecol.doc().set(vehicule.toMap());
      return true;
    } catch (e) {
      return false;
    }
  }

  Future updatevehicule(Vehicule vehicule) async {
    try {
      await vehiculecol.doc(vehicule.id).update(vehicule.toMap());
      return true;
    } catch (e) {
      return false;
    }
  }

  Future deletevehicule(String id) async {
    try {
      await vehiculecol.doc(id).delete();
      return true;
    } catch (e) {
      return false;
    }
  }

  Stream<List<Vehicule>> getvehicule({CarType type, String uid}) {
    return vehiculecol
        .where("type",
            isEqualTo: type == null
                ? null
                : type == CarType.car
                    ? "car"
                    : "moto")
        .where("uid", isEqualTo: uid)
        .snapshots()
        .map((vehicule) {
      return vehicule.docs
          .map((e) => Vehicule.fromJson(e.data(), id: e.id))
          .toList();
    });
  }

  Future getVSE(String id) async {
    try {
      final data = await vehiculecol.doc(id).get();
      final ves = Vehicule.fromJson(data.data());
      return ves;
    } catch (e) {
      return false;
    }
  }

  Stream<List<Vehicule>> getvehiculefav(CarType type) {
    final user = FirebaseAuth.instance.currentUser;
    return vehiculecol
        .where("type", isEqualTo: type == CarType.car ? "car" : "moto")
        .where("favories", arrayContains: user.uid)
        .snapshots()
        .map((vehicule) {
      return vehicule.docs
          .map((e) => Vehicule.fromJson(e.data(), id: e.id))
          .toList();
    });
  }

  Stream<List<UserM>> get getAllUsers {
    return usercol.snapshots().map((users) {
      return users.docs.map((e) => UserM.fromJson(e.data())).toList();
    });
  }

  Future<bool> add_comment(Comment comment) async {
    try {
      await commentcol.doc().set(
          comment.toMap()..update("date_comment", (value) => Timestamp.now()));
      return true;
    } catch (e) {
      return false;
    }
  }

  Stream<int> getCountComment(String id) {
    return commentcol
        .where("id_comment_pub", isEqualTo: id)
        .snapshots()
        .map((comments) {
      return comments.docs
          .map((e) => Comment.fromJson(e.data(), e.id))
          .toList()
          .length;
    });
  }

  Stream<List<Comment>> gecomment(String id) {
    return commentcol
        .where("id_comment_pub", isEqualTo: id)
        .snapshots()
        .map((comments) {
      return comments.docs
          .map((e) => Comment.fromJson(e.data(), e.id))
          .toList();
    });
  }

  Stream<List<Comment>> gecommentComment(String id) {
    return commentcol
        .where("id_comment", isEqualTo: id)
        .snapshots()
        .map((comments) {
      return comments.docs
          .map((e) => Comment.fromJson(e.data(), e.id))
          .toList();
    });
  }

  Stream<int> getCountCommentComment(String id) {
    return commentcol
        .where("id_comment", isEqualTo: id)
        .snapshots()
        .map((comments) {
      return comments.docs
          .map((e) => Comment.fromJson(e.data(), e.id))
          .toList()
          .length;
    });
  }

  Stream<DocumentSnapshot> getUserStream({@required String uid}) =>
      usercol.doc(uid).snapshots();
}
