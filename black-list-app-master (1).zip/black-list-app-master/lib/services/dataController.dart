import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';

class DataController extends GetxController {
  Future getData(String collection) async {
    final FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;
    QuerySnapshot snapshot =
        await firebaseFirestore.collection(collection).get();
    return snapshot.docs;
  }

  Future queryData(String queryString) async {
    return FirebaseFirestore.instance
        .collection('vehicule')
        .orderBy("ens")
        .startAt([queryString]).endAt(["$queryString\uf8ff"]).get();
  }

  Future queryData2(String queryString) async {
    return FirebaseFirestore.instance
        .collection('vehicule')
        .orderBy("prix")
        .startAt([queryString]).endAt(["$queryString\uf8ff"]).get();
  }

  Future queryData3(String queryString) async {
    return FirebaseFirestore.instance
        .collection('vehicule')
        .orderBy("permis")
        .startAt([queryString]).endAt(["$queryString\uf8ff"]).get();
  }

  Future queryData4(String queryString) async {
    return FirebaseFirestore.instance
        .collection('vehicule')
        .orderBy("ens2")
        .startAt([queryString]).endAt(["$queryString\uf8ff"]).get();
  }

  Future queryData5(String queryString) async {
    return FirebaseFirestore.instance
        .collection('vehicule')
        .orderBy("cart")
        .startAt([queryString]).endAt(["$queryString\uf8ff"]).get();
  }
}
