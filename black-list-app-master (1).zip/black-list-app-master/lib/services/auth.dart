import 'package:black_list_2/model/user.dart';
import 'package:black_list_2/services/db.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

class AuthServices {
  FirebaseAuth auth = FirebaseAuth.instance;
  final GoogleSignIn googlesignIn = GoogleSignIn();

  Future signinAnonimous() async {
    try {
      final result = await auth.signInAnonymously();
      return result.user;
    } catch (e) {
      print(e);
      return null;
    }
  }

  Future<User> get user async {
    final user = FirebaseAuth.instance.currentUser;
    return user;
  }

  Future<bool> signup(
      String email, pass, String pseudo, String nomeS, phone, rci) async {
    try {
      final result = await auth.createUserWithEmailAndPassword(
          email: email, password: pass);
      if (result.user != null) {
        await DBServices().saveUser(UserM(
            id: result.user.uid,
            email: email,
            pseudo: pseudo,
            nomeS: nomeS,
            phone: phone,
            rci: rci));
        return true;
      }

      return false;
    } catch (e) {
      return false;
    }
  }

  Future<bool> signin(String email, String pass) async {
    try {
      final result =
          await auth.signInWithEmailAndPassword(email: email, password: pass);
      if (result.user != null) return true;
      return false;
    } catch (e) {
      return false;
    }
  }

  Future<bool> resetpassword(String email) async {
    try {
      await auth.sendPasswordResetEmail(email: email);
      return true;
    } catch (e) {
      return false;
    }
  }

  Future<bool> googleSignIn() async {
    try {
      GoogleSignInAccount googleUser = await googlesignIn.signIn();
      GoogleSignInAuthentication googleAuth = await googleUser.authentication;
      final AuthCredential credential = GoogleAuthProvider.credential(
          idToken: googleAuth.idToken, accessToken: googleAuth.accessToken);
      final user = await auth.signInWithCredential(credential);
      if (user != null) return true;
      return false;
    } catch (e) {
      print(e);
      return false;
    }
  }

  Future signOut() async {
    try {
      final userD = FirebaseAuth.instance.currentUser;
      final u = await DBServices().getUser(userD.uid);
      await DBServices().updateUser(u..oneuser = !u.oneuser);
      return auth.signOut();
    } catch (e) {
      return null;
    }
  }

  Future signOut_t() async {
    try {
      return auth.signOut();
    } catch (e) {
      return null;
    }
  }
}
/*
62
*/
