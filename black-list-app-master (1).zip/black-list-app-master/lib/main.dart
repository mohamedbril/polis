import 'package:animated_splash_screen/animated_splash_screen.dart';
import 'package:black_list_2/screens/statutAuth.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_windowmanager/flutter_windowmanager.dart';
import 'package:lottie/lottie.dart';
import 'package:page_transition/page_transition.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  await FlutterWindowManager.addFlags(FlutterWindowManager.FLAG_SECURE);
  await FlutterWindowManager.addFlags(FlutterWindowManager.FLAG_KEEP_SCREEN_ON);
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(primaryColor: Colors.black),
      debugShowCheckedModeBanner: false,
      title: 'black list afm',
      home: Scaffold(
        body: AnimatedSplashScreen(
          backgroundColor: Colors.white,
          duration: 1000,
          splash: SizedBox(
            height: 200.0,
            width: 200.0,
            child: Lottie.asset(
              "assets/run3.json",
              fit: BoxFit.cover,
            ),
          ),
          centered: true,
          nextScreen: Statut(),
          //splashTransition: SplashTransition.rotationTransition,
          pageTransitionType: PageTransitionType.leftToRight,
        ),
      ),
    );
  }
}

/*
Image.asset('assets/logo.png',
            width: 300, height: 150, fit: BoxFit.fitHeight),

*/

/* 
flutter build apk --split-per-abi --no-shrink

*/
