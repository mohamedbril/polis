import 'package:black_list_2/model/user.dart';
import 'package:black_list_2/services/auth.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:black_list_2/model/vehicule.dart';
import 'package:black_list_2/screens/car_screen/carDetails.dart';
import 'package:black_list_2/screens/car_screen/updateCar.dart';
import 'package:black_list_2/screens/car_screen/updateMoto.dart';
import 'package:black_list_2/screens/comment/stream_comment_count.dart';
import 'package:black_list_2/services/db.dart';
import 'package:black_list_2/utils/constant.dart';
import 'package:black_list_2/utils/loading.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';

class VCard extends StatefulWidget {
  Vehicule car;
  CarType type;

  VCard({this.car, this.type = CarType.car});

  @override
  _VCardState createState() => _VCardState();
}

class _VCardState extends State<VCard> {
  AuthServices auth = AuthServices();
  UserM usertrue;

  Color likeColor = Colors.grey;

  Color dislikeColor = Colors.grey;

  Icon favIcon = Icon(
    FontAwesomeIcons.heart,
    size: 20,
  );
  final user = FirebaseAuth.instance.currentUser;

  get getUser async {
    final u = await DBServices().getUser(user.uid);
    if (u != null) {
      setState(() {
        usertrue = u;
      });
    }
  }

/*
  @override
  void initState() {
    super.initState();
    getUser();
  }
*/
  @override
  Widget build(BuildContext context) {
    getUser;
    bool iscar = widget.car.type == CarType.car ? true : false;
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;
    Color themeColor =
        widget.car.type == CarType.car ? Colors.green : Colors.lightBlue;
    final user = FirebaseAuth.instance.currentUser;
    if (widget.car.like.contains(user.uid)) {
      likeColor = Colors.lightBlue;
      dislikeColor = Colors.grey;
    } else if (widget.car.dislike.contains(user.uid)) {
      dislikeColor = Colors.red;
      likeColor = Colors.grey;
    } else {
      dislikeColor = Colors.grey;
      likeColor = Colors.grey;
    }

    if (widget.car.favories.contains(user.uid))
      favIcon = Icon(
        FontAwesomeIcons.solidHeart,
        size: 20,
        color: Colors.red,
      );
    else
      favIcon = Icon(
        FontAwesomeIcons.heart,
        size: 20,
        color: themeColor,
      );

    /*Future _incrementCounter() async {
      FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .get()
          .then((DocumentSnapshot documentSnapshot) {
        if (documentSnapshot.data()['admin']) {
          print('sdf');
          return 'sdf';
        }
      });
    }
    */

    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 0),
      child: InkWell(
        onTap: () {
          Navigator.of(context).push(MaterialPageRoute(
              builder: (ctx) => CarDetail(
                    v: widget.car,
                  )));
        },
        child: Container(
          decoration: BoxDecoration(
              border: Border.all(
                  color: widget.car.type == CarType.car
                      ? Colors.green
                      : Colors.lightBlue),
              borderRadius: BorderRadius.circular(30)),
          margin: EdgeInsets.symmetric(vertical: 5),
          child: Column(
            children: [
              Container(
                height: height / 4.2,
                width: width,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(20),
                        topRight: Radius.circular(20)),
                    image: DecorationImage(
                        fit: BoxFit.cover,
                        image: CachedNetworkImageProvider(
                            widget.car.images.first))),
                child: Container(
                  alignment: Alignment.topRight,
                  child: Card(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30)),
                    color: Colors.white,
                    child: IconButton(
                      icon: favIcon,
                      onPressed: () async {
                        if (widget.car.favories.contains(user.uid))
                          widget.car.favories.remove(user.uid);
                        else
                          widget.car.favories.add(user.uid);
                        await DBServices().updatevehicule(widget.car);
                      },
                    ),
                  ),
                ),
                // child: ,
              ),
              Container(
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin:
                                EdgeInsets.only(left: 10, right: 10, top: 10),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(widget.car.marque,
                                    style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 20,
                                        fontWeight: FontWeight.bold,
                                        height: 1)),
                                Text(widget.car.modele),
                                Text(widget.car.cart),
                              ],
                            ),
                          ),
                          Row(
                            children: [
                              IconButton(
                                icon: Icon(
                                  FontAwesomeIcons.solidThumbsUp,
                                  color: likeColor,
                                  size: 20,
                                ),
                                onPressed: () async {
                                  if (widget.car.like.contains(user.uid)) {
                                    widget.car.like.remove(user.uid);
                                  } else if (widget.car.dislike
                                      .contains(user.uid)) {
                                    widget.car.dislike.remove(user.uid);
                                    widget.car.like.add(user.uid);
                                  } else {
                                    widget.car.like.add(user.uid);
                                  }
                                  await DBServices().updatevehicule(widget.car);
                                },
                              ),
                              Text(widget.car.like.length.toString()),
                              IconButton(
                                icon: Icon(
                                  FontAwesomeIcons.solidThumbsDown,
                                  color: dislikeColor,
                                  size: 20,
                                ),
                                onPressed: () async {
                                  if (widget.car.dislike.contains(user.uid)) {
                                    widget.car.dislike.remove(user.uid);
                                  } else if (widget.car.like
                                      .contains(user.uid)) {
                                    widget.car.like.remove(user.uid);
                                    widget.car.dislike.add(user.uid);
                                  } else {
                                    widget.car.dislike.add(user.uid);
                                  }
                                  await DBServices().updatevehicule(widget.car);
                                },
                              ),
                              Text(widget.car.dislike.length.toString()),
                              StreamProvider<int>.value(
                                value:
                                    DBServices().getCountComment(widget.car.id),
                                child: StreamComment(vehicule: widget.car),
                              )
                            ],
                          )
                        ],
                      ),
                      if (usertrue != null)
                        if (widget.car.uid.contains(user.uid) || usertrue.admin)
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              IconButton(
                                icon: Icon(
                                  Icons.delete,
                                  color: Colors.red,
                                ),
                                onPressed: () {
                                  mydialog(context,
                                      title: "Suppression",
                                      content: "Voulez-vous supprimer " +
                                          widget.car.marque, ok: () async {
                                    Navigator.of(context).pop();
                                    loading(context);
                                    bool delete = await DBServices()
                                        .deletevehicule(widget.car.id);
                                    if (delete != null) {
                                      Navigator.of(context).pop();
                                    }
                                  });
                                },
                              ),
                              IconButton(
                                padding: EdgeInsets.only(right: 20.0),
                                icon: Icon(Icons.edit, color: themeColor),
                                onPressed: () {
                                  Navigator.of(context).push(MaterialPageRoute(
                                      builder: (ctx) => iscar
                                          ? UpdateCar(v: widget.car)
                                          : UpdateMoto(
                                              v: widget.car,
                                            )));
                                },
                              )
                            ],
                          )
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Object incrementCounter() {}
}

// child: ListTile(
//   onTap: () {
// Navigator.of(context).push(MaterialPageRoute(
//     builder: (ctx) => CarDetail(
//           v: car,
//         )));
//   },
//   subtitle: Column(
//     crossAxisAlignment: CrossAxisAlignment.start,
//     children: [
//       Text(car.modele),
// Row(
//   children: [
//     IconButton(
//       icon: Icon(
//         FontAwesomeIcons.solidThumbsUp,
//         color: likeColor,
//         size: 20,
//       ),
//       onPressed: () async {
//         if (car.like.contains(user.uid)) {
//           car.like.remove(user.uid);
//         } else if (car.dislike.contains(user.uid)) {
//           car.dislike.remove(user.uid);
//           car.like.add(user.uid);
//         } else {
//           car.like.add(user.uid);
//         }
//         await DBServices().updatevehicule(car);
//       },
//     ),
//     Text(car.like.length.toString()),
//     IconButton(
//       icon: Icon(
//         FontAwesomeIcons.solidThumbsDown,
//         color: dislikeColor,
//         size: 20,
//       ),
//       onPressed: () async {
//         if (car.dislike.contains(user.uid)) {
//           car.dislike.remove(user.uid);
//         } else if (car.like.contains(user.uid)) {
//           car.like.remove(user.uid);
//           car.dislike.add(user.uid);
//         } else {
//           car.dislike.add(user.uid);
//         }
//         await DBServices().updatevehicule(car);
//       },
//     ),
//     Text(car.dislike.length.toString()),
//   ],
// )
//   ],
// ),
//   leading: Container(
//     child: Image(
//       height: 50,
//       width: 50,
//       image: NetworkImage(car.images.first),
//     ),
//   ),
// trailing: car.uid == FirebaseAuth.instance.currentUser.uid
//     ? Row(
//         mainAxisSize: MainAxisSize.min,
//         children: [
//           IconButton(
//             icon: Icon(
//               Icons.delete,
//               color: Colors.red,
//             ),
//             onPressed: () {
//               mydialog(context,
//                   title: "Suppression",
//                   content: "Voulez-vous supprimer " + car.marque,
//                   ok: () async {
//                 Navigator.of(context).pop();
//                 loading(context);
//                 bool delete =
//                     await DBServices().deletevehicule(car.id);
//                 if (delete != null) {
//                   Navigator.of(context).pop();
//                 }
//               });
//             },
//           ),
//           IconButton(
//             icon: Icon(Icons.edit, color: themeColor),
//             onPressed: () {
//               Navigator.of(context).push(MaterialPageRoute(
//                   builder: (ctx) => iscar
//                       ? UpdateCar(v: car)
//                       : UpdateMoto(
//                           v: car,
//                         )));
//             },
//           )
//         ],
//       )
//       : null,
//   title: Text(car.marque),
// ),
