import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

TextStyle style = TextStyle(color: Colors.black, fontSize: 25);

mydialog(BuildContext context,
    {String title, String content, VoidCallback ok}) async {
  AwesomeDialog(
    context: context,
    dialogType: DialogType.INFO_REVERSED,
    borderSide: BorderSide(color: Colors.green, width: 2),
    width: 350,
    buttonsBorderRadius: BorderRadius.all(Radius.circular(2)),
    headerAnimationLoop: true,
    animType: AnimType.BOTTOMSLIDE,
    title: title,
    btnOkText: 'oui',
    btnCancelText: 'non',
    desc: content,
    showCloseIcon: true,
    btnCancelOnPress: () {
      Navigator.of(context).pop();
    },
    btnOkOnPress: () {
      ok();
    },
  )..show();

  /*showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: Text(title),
          content: Text(content),
          actions: [
            FlatButton(
              onPressed: ok,
              child: Text("Oui"),
            ),
            FlatButton(
              onPressed: () async {
                Navigator.of(context).pop();
              },
              child: Text("Non"),
            ),
          ],
        );
      });*/
}

messages(String msg) {
  return Fluttertoast.showToast(
      msg: "$msg",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      timeInSecForIosWeb: 2,
      backgroundColor: Colors.redAccent,
      textColor: Colors.white,
      fontSize: 16.0);
}
