import 'package:black_list_2/model/user.dart';
import 'package:black_list_2/services/db.dart';
import 'package:flutter/widgets.dart';

class UserProvider with ChangeNotifier {
  UserM _user;
  DBServices _authMethods = DBServices();

  UserM get getUser => _user;

  Future<void> refreshUser() async {
    UserM user = await _authMethods.getUserDetails();
    _user = user;
    notifyListeners();
  }
}
