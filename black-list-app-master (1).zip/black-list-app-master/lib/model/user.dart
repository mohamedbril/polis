class UserM {
  String id, email, pseudo, image, rci, phone, nomeS;
  bool admin, enable, oneuser;
  int state;
  static UserM currentUser;
  UserM(
      {this.id,
      this.pseudo,
      this.rci,
      this.state,
      this.phone,
      this.oneuser = false,
      this.nomeS,
      this.email,
      this.image,
      this.admin = false,
      this.enable = false});
  factory UserM.fromJson(Map<String, dynamic> j) => UserM(
      email: j['email'],
      id: j['id'],
      nomeS: j['nomeS'],
      state: j['state'],
      pseudo: j['pseudo'],
      oneuser: j['oneuser'],
      phone: j['phone'],
      rci: j['rci'],
      image: j['image'],
      admin: j['admin'],
      enable: j["enable"]);
  Map<String, dynamic> toMap() => {
        "id": id,
        "email": email,
        "rci": rci,
        "phone": phone,
        "state": state,
        "nomeS": nomeS,
        "oneuser": oneuser,
        "pseudo": pseudo,
        "image": image,
        "admin": admin,
        "enable": enable
      };
  UserM.fromMap(Map<String, dynamic> mapData) {
    this.state = mapData['state'];
  }
}
