class Vehicule {
  List<String> images;
  List<String> like;
  List<String> dislike;
  List<String> favories;
  String marque;
  String modele;
  String prix;
  String ens;
  String permis;
  String ens2;
  String cart;
  String detailSup;
  String uid;
  CarType type;
  String id;
  Vehicule(
      {this.detailSup,
      this.images,
      this.marque,
      this.modele,
      this.ens,
      this.ens2,
      this.prix,
      this.permis,
      this.cart,
      this.type,
      this.id,
      this.uid,
      this.dislike,
      this.like,
      this.favories});

  factory Vehicule.fromJson(Map<String, dynamic> map, {String id}) => Vehicule(
      id: id,
      marque: map["marque"],
      modele: map["modele"],
      prix: map["prix"],
      ens2: map["ens2"],
      permis: map["permis"],
      ens: map["ens"],
      cart: map["cart"],
      detailSup: map["detailSup"],
      uid: map["uid"],
      images: map["images"].map<String>((i) => i as String).toList(),
      like: map["like"] == null
          ? []
          : map["like"].map<String>((i) => i as String).toList(),
      favories: map["favories"] == null
          ? []
          : map["favories"].map<String>((i) => i as String).toList(),
      dislike: map["dislike"] == null
          ? []
          : map["dislike"].map<String>((i) => i as String).toList(),
      type: map["type"] == "car" ? CarType.car : CarType.moto);

  Map<String, dynamic> toMap() {
    return {
      "type": type == CarType.car ? "car" : "moto",
      "images": images,
      "marque": marque,
      "modele": modele,
      "permis": permis,
      "detailSup": detailSup,
      "prix": prix,
      "ens2": ens2,
      "cart": cart,
      "uid": uid,
      "ens": ens,
      "like": like,
      "dislike": dislike,
      "favories": favories
    };
  }
}

enum CarType { car, moto }
