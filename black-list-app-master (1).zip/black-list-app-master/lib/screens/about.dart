import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

TextStyle style = TextStyle(color: Colors.black, fontSize: 25);

class AboutPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;
    return Container(
      child: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          title: Text("Contact"),
          backgroundColor: Colors.amber[600],
        ),
        body: Center(
          child: SingleChildScrollView(
            reverse: true,
            child: Column(
              children: [
                /*Container(
                  height: height / 2,
                  width: width,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(20),
                          topRight: Radius.circular(20)),
                      image: DecorationImage(
                          fit: BoxFit.cover,
                          image: CachedNetworkImageProvider(
                            
                              'https://firebasestorage.googleapis.com/v0/b/black-liste-c96b0.appspot.com/o/profil%2F199387212_1488826778148265_8863057923793893700_n.jpg?alt=media&token=01d0be5a-04c4-4256-aab8-ed733d5d4a7c'))),
                ),*/
                Container(
                  child: Image(
                    height: height / 3,
                    width: width,
                    image: NetworkImage(
                        'https://firebasestorage.googleapis.com/v0/b/black-liste-c96b0.appspot.com/o/profil%2F199387212_1488826778148265_8863057923793893700_n.jpg?alt=media&token=01d0be5a-04c4-4256-aab8-ed733d5d4a7c'),
                  ),
                ),
                SizedBox(
                  height: 15.0,
                ),
                item("chambre de Commerce d'Imdudtrie et de Services",
                    FontAwesomeIcons.hotel),
                SizedBox(
                  height: 15.0,
                ),
                item("Tel : +212 6 32 00 36 36", FontAwesomeIcons.phoneAlt),
                SizedBox(
                  height: 15.0,
                ),
                item("email : afmmarrakech@gmail.com",
                    FontAwesomeIcons.envelope),
                SizedBox(
                  height: 15.0,
                ),
                item("https://afmarrakech.com", FontAwesomeIcons.globe),
                SizedBox(
                  height: 15.0,
                ),
                item("Président : Mr Ab Halim Douma", FontAwesomeIcons.user),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

ListTile item(String title, IconData icon) {
  return ListTile(
    leading: Icon(
      icon,
      color: Colors.amber[600],
      size: 35.0,
    ),
    title: Text(
      title,
      style: style.copyWith(fontSize: 15),
    ),
  );
}
