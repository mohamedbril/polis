import 'package:flutter/material.dart';

class PubListPage extends StatefulWidget {
  @override
  _PubListPageState createState() => _PubListPageState();
}

class _PubListPageState extends State<PubListPage> {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text("Publication"),
    );
  }
}
