import 'package:black_list_2/model/user.dart';
import 'package:black_list_2/model/vehicule.dart';
import 'package:black_list_2/utils/vehiculeCard.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

class DetailUser extends StatelessWidget {
  final UserM user;
  DetailUser({this.user});
  @override
  Widget build(BuildContext context) {
    final List<Vehicule> cars = Provider.of<List<Vehicule>>(context);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red,
        title: Text("Informations de l'utilisateur"),
      ),
      body: cars == null
          ? Center(
              child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(Colors.red),
              ),
            )
          : ListView.builder(
              padding: EdgeInsets.only(top: 10),
              itemCount: cars.length + 1,
              itemBuilder: (_, i) {
                if (i == 0) {
                  return Column(
                    children: [
                      Container(
                        margin: EdgeInsets.only(bottom: 10),
                        child: CircleAvatar(
                          radius: 100,
                          backgroundColor: Colors.red,
                          backgroundImage: user.image != null
                              ? NetworkImage(user.image)
                              : null,
                          child: user.image != null
                              ? Container()
                              : Icon(Icons.person, color: Colors.white),
                        ),
                      ),
                      Text("Nom de société : ${user.nomeS}",
                          style: Theme.of(context).textTheme.headline6),
                      SizedBox(
                        width: 30,
                        height: 15,
                      ),
                      Text("numéro de RC : ${user.rci}",
                          style: Theme.of(context).textTheme.headline6),
                      SizedBox(
                        width: 30,
                        height: 15,
                      ),
                      Text(
                        "Nom de gerant : ${user.pseudo}",
                        style: Theme.of(context).textTheme.headline6,
                      ),
                      SizedBox(
                        width: 30,
                        height: 15,
                      ),
                      GestureDetector(
                        onTap: () {
                          launchURL("tel:${user.phone}");
                        },
                        child: Text("Numéro de téléphone : ${user.phone}",
                            style: Theme.of(context).textTheme.headline6),
                      ),
                      SizedBox(
                        width: 30,
                        height: 15,
                      ),
                      GestureDetector(
                        onTap: () {
                          launchURL("mailto:${user.email}");
                        },
                        child: Text("Email: ${user.email}",
                            style: Theme.of(context).textTheme.headline6),
                      ),
                      Container(
                        alignment: Alignment.centerLeft,
                        margin: EdgeInsets.only(top: 20, left: 10),
                        child: Text("Publications: ${cars.length}",
                            style: Theme.of(context).textTheme.headline6),
                      ),
                    ],
                  );
                } else {
                  final car = cars[i - 1];
                  return i == cars.length
                      ? Container(
                          child: VCard(car: car),
                          margin: EdgeInsets.only(bottom: 80),
                        )
                      : VCard(car: car);
                }
              }),
    );
  }
}

launchURL(String url) async {
  if (await canLaunch(url)) {
    await launch(url);
  } else {
    throw 'Could not launch $url';
  }
}
