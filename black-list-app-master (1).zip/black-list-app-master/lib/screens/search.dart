import 'package:black_list_2/model/vehicule.dart';
import 'package:black_list_2/services/dataController.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';

import 'car_screen/searchDetail.dart';

class SearchPage extends StatefulWidget {
  @override
  _SearchPageState createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  Vehicule v;
  final TextEditingController searchController = TextEditingController();
  QuerySnapshot snapshotData;
  bool isExcecuted = false;
  bool ishere = false;
  @override
  Widget build(BuildContext context) {
    Widget searchedData() {
      return ListView.builder(
        itemCount: snapshotData.docs.length,
        itemBuilder: (BuildContext context, int index) {
          return GestureDetector(
            onTap: () {
              Navigator.of(context).push(MaterialPageRoute(
                  builder: (ctx) => SarchDeti(
                        v: snapshotData,
                        d: index,
                      )));

              /*    Get.to(CarDetail(),
                  transition: Transition.downToUp,
                  arguments: snapshotData.docs[index]);
            */
              print(index);
            },
            child: ListTile(
              leading: CircleAvatar(
                backgroundImage: NetworkImage(
                    snapshotData.docs[index].data()['images'].first),
              ),
              title: Text(
                snapshotData.docs[index].data()['marque'] ?? '',
                style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                    fontSize: 24.0),
              ),
              subtitle: Text(
                snapshotData.docs[index].data()['modele'] ?? '',
                style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.normal,
                    fontSize: 10.0),
              ),
            ),
          );
        },
      );
    }

    return Scaffold(
        floatingActionButton: FloatingActionButton(
          child: Icon(
            Icons.clear,
            color: Colors.amberAccent,
          ),
          onPressed: () {
            setState(() {
              isExcecuted = false;
              searchController.clear();
            });
          },
        ),
        backgroundColor: Colors.white,
        appBar: AppBar(
          actions: [
            GetBuilder<DataController>(
              init: DataController(),
              builder: (val) {
                return IconButton(
                    onPressed: () {
                      val
                          .queryData(searchController.text.toLowerCase())
                          .then((value) {
                        snapshotData = value;
                        if (snapshotData.docs.length != 0) {
                          setState(() {
                            isExcecuted = true;
                          });
                        } else {
                          val
                              .queryData4(searchController.text.toLowerCase())
                              .then((value) {
                            snapshotData = value;

                            if (snapshotData.docs.length != 0) {
                              setState(() {
                                isExcecuted = true;
                              });
                            } else {
                              val
                                  .queryData3(searchController.text)
                                  .then((value) {
                                snapshotData = value;
                                if (snapshotData.docs.length != 0) {
                                  setState(() {
                                    isExcecuted = true;
                                  });
                                } else {
                                  val
                                      .queryData2(searchController.text)
                                      .then((value) {
                                    snapshotData = value;
                                    if (snapshotData.docs.length != 0) {
                                      setState(() {
                                        isExcecuted = true;
                                      });
                                    } else {
                                      val
                                          .queryData5(searchController.text
                                              .toUpperCase())
                                          .then((value) {
                                        snapshotData = value;
                                        setState(() {
                                          isExcecuted = true;
                                        });
                                      });
                                    }
                                  });
                                }
                              });
                            }
                          });
                        }
                      });
                    },
                    icon: Icon(
                      Icons.search,
                      color: Colors.amber[900],
                    ));
              },
            )
          ],
          title: GetBuilder<DataController>(
              init: DataController(),
              builder: (val) {
                return TextField(
                  textInputAction: TextInputAction.go,
                  onEditingComplete: () {
                    val
                        .queryData(searchController.text.toLowerCase())
                        .then((value) {
                      snapshotData = value;
                      if (snapshotData.docs.length != 0) {
                        setState(() {
                          isExcecuted = true;
                        });
                      } else {
                        val
                            .queryData4(searchController.text.toLowerCase())
                            .then((value) {
                          snapshotData = value;

                          if (snapshotData.docs.length != 0) {
                            setState(() {
                              isExcecuted = true;
                            });
                          } else {
                            val.queryData3(searchController.text).then((value) {
                              snapshotData = value;
                              if (snapshotData.docs.length != 0) {
                                setState(() {
                                  isExcecuted = true;
                                });
                              } else {
                                val
                                    .queryData2(searchController.text)
                                    .then((value) {
                                  snapshotData = value;
                                  if (snapshotData.docs.length != 0) {
                                    setState(() {
                                      isExcecuted = true;
                                    });
                                  } else {
                                    val
                                        .queryData5(
                                            searchController.text.toUpperCase())
                                        .then((value) {
                                      snapshotData = value;
                                      setState(() {
                                        isExcecuted = true;
                                      });
                                    });
                                  }
                                });
                              }
                            });
                          }
                        });
                      }
                    });
                  },
                  style: TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                      hintText: 'search here',
                      hintStyle: TextStyle(color: Colors.amber)),
                  controller: searchController,
                );
              }),
          backgroundColor: Colors.blue[900],
        ),
        body: isExcecuted
            ? searchedData()
            : Container(
                child: Center(
                    heightFactor: 500.0,
                    widthFactor: 500.0,
                    child: Lottie.asset('assets/run2.json', fit: BoxFit.cover)),
              ));
  }

  void newMethod2(DataController val) {
    val.queryData2(searchController.text).then((value) {
      snapshotData = value;
      setState(() {
        isExcecuted = true;
      });
    });
  }

  void newMethod(DataController val) {
    val.queryData(searchController.text).then((value) {
      snapshotData = value;
      setState(() {
        isExcecuted = true;
      });
    });
  }
}
/*
 getVSE() async {
                final u = await DBServices().getUser(index.toString());
                if (u != null) {
                  setState(() {
                    v = u;
                    print('object');
                  });
                }
              }

              @override
              void initState() {
                super.initState();

                getVSE();
              }

              getVSE();
              print(v.cart.toString());

              Navigator.of(context).push(MaterialPageRoute(
                  builder: (ctx) => CarDetail(
                        v: v,
                      )));

*/
