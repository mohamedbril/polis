import 'package:black_list_2/model/user.dart';
import 'package:black_list_2/screens/car_screen/reste_page.dart';
import 'package:black_list_2/screens/register.dart';
import 'package:black_list_2/screens/statutAuth.dart';
import 'package:black_list_2/services/auth.dart';
import 'package:black_list_2/services/db.dart';
import 'package:black_list_2/utils/constant.dart';
import 'package:black_list_2/utils/loading.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  AuthServices auth = AuthServices();
  String email, pass;
  final keys = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Login"),
        centerTitle: true,
      ),
      body: Center(
          child: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.all(15),
          child: Form(
            key: keys,
            child: Column(
              children: [
                Text("Se Connecter", style: style),
                SizedBox(
                  height: 15,
                ),
                TextFormField(
                  keyboardType: TextInputType.emailAddress,
                  onChanged: (e) => email = e,
                  validator: (e) => e.isEmpty ? "Champ vide" : null,
                  decoration: InputDecoration(
                      hintText: "Entrer votre email", labelText: "Email"),
                ),
                TextFormField(
                  obscureText: true,
                  onChanged: (e) => pass = e,
                  validator: (e) => e.isEmpty
                      ? "Champ vide"
                      : e.length < 6
                          ? "le password doit être plus de 6"
                          : null,
                  decoration: InputDecoration(
                      hintText: "Entrer votre Password", labelText: "Password"),
                ),
                SizedBox(
                  height: 10,
                ),
                FlatButton(
                  child: Text("Mot de passe oublié",
                      style: TextStyle(color: Colors.lightBlue)),
                  onPressed: () {
                    Navigator.of(context).push(
                        MaterialPageRoute(builder: (ctx) => ResetPassword()));
                  },
                ),
                RaisedButton(
                  onPressed: () async {
                    if (keys.currentState.validate()) {
                      loading(context);
                      print(email + "    " + pass);
                      bool login = await auth.signin(email, pass);
                      if (login != null) {
                        final userD = FirebaseAuth.instance.currentUser;
                        UserM u = await DBServices().getUser(userD.uid);
                        if (u != null) {
                          if (!u.oneuser) {
                            setState(() async {
                              await DBServices()
                                  .updateUser(u..oneuser = !u.oneuser);
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => Statut()));
                            });
                          } else {
                            messages("Ce Email est deja utilise");
                            await auth.signOut_t();
                          }
                        }
                        if (!login) messages("Email ou mot de passe incorrect");
                      }
                    }
                  },
                  child: Text("Se Connecter"),
                ),
                SizedBox(height: 15),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 15,
                    ),
                  ],
                ),
                SizedBox(height: 15),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text("Avez-vous un compte ?"),
                    FlatButton(
                        onPressed: () {
                          Navigator.of(context).push(
                              MaterialPageRoute(builder: (ctx) => Register()));
                        },
                        child: Text("Creer un Compte"))
                  ],
                )
              ],
            ),
          ),
        ),
      )),
    );
  }
}
