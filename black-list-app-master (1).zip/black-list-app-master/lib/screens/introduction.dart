import 'dart:ui';

import 'package:black_list_2/screens/login.dart';
import 'package:black_list_2/utils/constant.dart';
import 'package:flutter/material.dart';
import 'package:introduction_screen/introduction_screen.dart';
import 'package:url_launcher/url_launcher.dart';

class Intro extends StatefulWidget {
  @override
  _IntroState createState() => _IntroState();
}

class _IntroState extends State<Intro> {
  bool checkedValue = false;
  bool checkedValuer = false;
  bool checkedValuef = false;
  List<PageViewModel> getPage() {
    return [
      PageViewModel(
        image: Image.network(
            'https://image.freepik.com/free-vector/light-bulb-people-discussing-ideas-working_1262-19265.jpg'),
        title: 'Quel est le but de créer cet application blacklist de AFM ?',
        body: 'Le but est de diminuer les cas des vols ...',
        footer: GestureDetector(
            onTap: () {
              launchURL("tel:0600000000");
            },
            child: Text('@afm admins')),
      ),
      PageViewModel(
        image: Image.network(
            'https://image.freepik.com/free-vector/engineer-developer-with-laptop-tablet-code-cross-platform-development-cross-platform-operating-systems-software-environments-concept-bright-vibrant-violet-isolated-illustration_335657-312.jpg'),
        title: 'copyright',
        body: 'L application a été développé par MBstudio ',
        footer: GestureDetector(
            onTap: () {
              launchURL("mailto:mohabril1972@gmail.com");
            },
            child: Text('@MB studio')),
      ),
      PageViewModel(
        image: Image.network(
            'https://image.freepik.com/free-vector/goal-achievement-teamwork-business-concept-career-growth-cooperation-development-project_107791-29.jpg?1'),
        title: 'les conditions de participation ',
        bodyWidget: Column(
          children: [
            CheckboxListTile(
              checkColor: Colors.red,
              title: Text(
                  "Je suis le seul responsable de la saisie des informations erronées\nأنا المسؤول الوحيد عن إدخال معلومات غير صحيحة",
                  style: style.copyWith(fontSize: 12.0)),
              value: checkedValue,
              onChanged: (newValue) {
                setState(() {
                  checkedValue = newValue;
                });
              },
              controlAffinity:
                  ListTileControlAffinity.leading, //  <-- leading Checkbox
            ),
            CheckboxListTile(
              checkColor: Colors.red,
              title: Text(
                  "Je n'ai pas le droit de publier ces informations \n ليس لدي الحق في نشر هذه المعلومات ",
                  style: style.copyWith(fontSize: 13.0)),
              value: checkedValuer,
              onChanged: (newValue) {
                setState(() {
                  checkedValuer = newValue;
                });
              },
              controlAffinity:
                  ListTileControlAffinity.leading, //  <-- leading Checkbox
            ),
            CheckboxListTile(
              checkColor: Colors.red,
              title: Text(
                "Les plaintes sont nécessaires pour enregistrer un personne \n الشكاية ضرورية لتسجيل اي شخص",
                style: style.copyWith(fontSize: 13.0),
              ),
              value: checkedValuef,
              onChanged: (newValue) {
                setState(() {
                  checkedValuef = newValue;
                });
              },
              controlAffinity:
                  ListTileControlAffinity.leading, //  <-- leading Checkbox
            )
          ],
        ),
        footer: Text('@afm admins'),
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: IntroductionScreen(
          done: const Text(
            'accept',
            style: TextStyle(color: Colors.red),
          ),
          showNextButton: true,
          next: const Text('Next'),
          showDoneButton: true,
          onDone: () {
            if (checkedValue && checkedValuer && checkedValuef) {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => LoginPage()));
            } else {
              messages("rempli tous les cases");
            }
          },
          pages: getPage(),
          globalBackgroundColor: Colors.white,
        ),
      ),
    );
  }
}

launchURL(String url) async {
  if (await canLaunch(url)) {
    await launch(url);
  } else {
    throw 'Could not launch $url';
  }
}
