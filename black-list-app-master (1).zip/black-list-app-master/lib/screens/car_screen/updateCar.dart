import 'dart:io';

import 'package:black_list_2/model/vehicule.dart';
import 'package:black_list_2/services/db.dart';
import 'package:black_list_2/utils/constant.dart';
import 'package:black_list_2/utils/getImage.dart';
import 'package:black_list_2/utils/loading.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class UpdateCar extends StatefulWidget {
  Vehicule v;
  UpdateCar({this.v});
  @override
  _UpdateCarState createState() => _UpdateCarState();
}

class _UpdateCarState extends State<UpdateCar> {
  final key = GlobalKey<FormState>();
  String marque, model, prix, descrition, permis, cart;
  List<dynamic> images = [];

  Vehicule car = Vehicule();
  void initState() {
    // TODO: implement initState
    super.initState();
    car.type = CarType.car;
    marque = widget.v.marque;
    prix = widget.v.prix;
    permis = widget.v.permis;
    cart = widget.v.cart;
    model = widget.v.modele;
    descrition = widget.v.detailSup;
    images.addAll(widget.v.images);
    car = widget.v;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Modifier " + widget.v.marque),
          backgroundColor: Colors.green,
          actions: [Icon(FontAwesomeIcons.userSecret)],
        ),
        body: SingleChildScrollView(
          child: Container(
            padding: EdgeInsets.all(10),
            child: Form(
              key: key,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TextFormField(
                    initialValue: marque,
                    validator: (e) => e.isEmpty ? "Remplir se champ" : null,
                    onChanged: (e) => marque = e,
                    decoration: InputDecoration(
                        hintText: "Nome",
                        labelText: "Nome",
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10))),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  TextFormField(
                    initialValue: model,
                    validator: (e) => e.isEmpty ? "Remplir se champ" : null,
                    onChanged: (e) => model = e,
                    decoration: InputDecoration(
                        hintText: "Prénom",
                        labelText: "Prénom",
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10))),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  TextFormField(
                    initialValue: cart,
                    validator: (e) => e.isEmpty ? "Remplir se champ" : null,
                    onChanged: (e) => cart = e,
                    decoration: InputDecoration(
                        hintText: "Cart national",
                        labelText: "Cart National",
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10))),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  TextFormField(
                    initialValue: permis,
                    keyboardType: TextInputType.number,
                    validator: (e) => e.isEmpty ? "Remplir se champ" : null,
                    onChanged: (e) => permis = e,
                    decoration: InputDecoration(
                        hintText: "Permis de Conduire",
                        labelText: "Permis",
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10))),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  TextFormField(
                    initialValue: prix,
                    keyboardType: TextInputType.number,
                    validator: (e) => e.isEmpty ? "numéro de téléphone" : null,
                    onChanged: (e) => prix = e,
                    decoration: InputDecoration(
                        hintText: "numéro de téléphone",
                        labelText: "Tel",
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10))),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  TextFormField(
                    initialValue: descrition,
                    validator: (e) => e.isEmpty ? "Remplir se champ" : null,
                    onChanged: (e) => descrition = e,
                    maxLines: 5,
                    decoration: InputDecoration(
                        hintText: "Détails supplémentaires",
                        labelText: "Détails",
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10))),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Wrap(
                    children: [
                      for (int i = 0; i < images.length; i++)
                        Container(
                          decoration: BoxDecoration(
                              color: Colors.black.withOpacity(.4)),
                          margin: EdgeInsets.only(right: 5, bottom: 5),
                          height: 70,
                          width: 70,
                          child: Stack(
                            children: [
                              if (images[i] is File)
                                Image.file(
                                  images[i],
                                  fit: BoxFit.fitHeight,
                                ),
                              if (images[i] is String)
                                Image.network(
                                  images[i],
                                  fit: BoxFit.fitHeight,
                                ),
                              Align(
                                alignment: Alignment.center,
                                child: IconButton(
                                  icon: Icon(
                                    FontAwesomeIcons.minusCircle,
                                    color: Colors.white,
                                  ),
                                  onPressed: () {
                                    setState(() {
                                      images.removeAt(i);
                                    });
                                  },
                                ),
                              )
                            ],
                          ),
                        ),
                      InkWell(
                        onTap: () async {
                          final data = await showModalBottomSheet(
                              context: context,
                              builder: (ctx) {
                                return GetImage();
                              });
                          if (data != null)
                            setState(() {
                              images.add(data);
                            });
                        },
                        child: Container(
                          width: 60,
                          height: 60,
                          color: Colors.green,
                          child: Icon(
                            FontAwesomeIcons.plusCircle,
                            color: Colors.white,
                          ),
                        ),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width,
                    child: FlatButton(
                      shape: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                      color: Colors.green,
                      onPressed: () async {
                        if (key.currentState.validate() && images.length > 0) {
                          loading(context);
                          car.marque = marque;
                          car.modele = model;
                          car.prix = prix;
                          car.detailSup = descrition;
                          car.images = [];
                          car.uid = FirebaseAuth.instance.currentUser.uid;
                          for (var i = 0; i < images.length; i++) {
                            if (images[i] is File) {
                              String urlImage = await DBServices()
                                  .uploadImage(images[i], path: "cars");
                              if (urlImage != null) car.images.add(urlImage);
                            } else {
                              car.images.add(images[i]);
                            }
                          }
                          if (images.length == car.images.length) {
                            bool update =
                                await DBServices().updatevehicule(car);
                            if (update) {
                              Navigator.of(context).pop();
                              Navigator.of(context).pop();
                            }
                            ;
                          }
                        } else {
                          print("veillez remplir tous les champs");
                        }
                      },
                      child: Text("Modifier",
                          style: style.copyWith(
                              color: Colors.white, fontSize: 20)),
                    ),
                  )
                ],
              ),
            ),
          ),
        ));
  }
}
