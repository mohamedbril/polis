import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:black_list_2/model/user.dart';
import 'package:black_list_2/model/vehicule.dart';
import 'package:black_list_2/services/db.dart';
import 'package:black_list_2/utils/constant.dart';
import 'package:black_list_2/utils/slider.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:whatsapp_unilink/whatsapp_unilink.dart';

class SarchDeti extends StatefulWidget {
  final QuerySnapshot v;
  final int d;
  SarchDeti({this.v, this.d});

  @override
  _SarchDetiState createState() => _SarchDetiState();
}

class _SarchDetiState extends State<SarchDeti> {
  Color color = Colors.green;

  UserM user;
  UserM usertrue;

  get getUser async {
    final u = await DBServices().getUser(widget.v.docs[widget.d].data()['uid']);
    if (u != null) {
      setState(() {
        user = u;
      });
    }
  }

  final usera = FirebaseAuth.instance.currentUser;

  get getUsert async {
    final u = await DBServices().getUser(usera.uid);
    if (u != null) {
      setState(() {
        usertrue = u;
      });
    }
  }

  @override
  void initState() {
    super.initState();

    getUser;
    getUsert;
  }

  @override
  Widget build(BuildContext context) {
    getUser;
    getUsert;
    launchWhatsApp() async {
      final link = WhatsAppUnilink(
        phoneNumber: '+212${user.phone}',
        text:
            "salam \nje veux savoir plus des informations sur: \n${widget.v.docs[widget.d].data()['marque']}\n${widget.v.docs[widget.d].data()['modele']}\n${widget.v.docs[widget.d].data()['cart']}\n${widget.v.docs[widget.d].data()['prix']} ",
      );
      await launch('$link');
    }

    color = widget.v.docs[widget.d].data()['type'] == CarType.car
        ? Colors.green
        : Colors.lightBlue;
    IconData icon = widget.v.docs[widget.d].data()['type'] == CarType.car
        ? FontAwesomeIcons.carAlt
        : FontAwesomeIcons.motorcycle;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: color,
        title: Text(widget.v.docs[widget.d].data()['marque']),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Sliders(imgs: widget.v.docs[widget.d].data()['images']),
            SizedBox(
              height: 10,
            ),
            item(widget.v.docs[widget.d].data()['marque'],
                FontAwesomeIcons.addressBook),
            item(widget.v.docs[widget.d].data()['modele'],
                FontAwesomeIcons.addressBook),
            item(widget.v.docs[widget.d].data()['cart'],
                FontAwesomeIcons.addressCard),
            item(widget.v.docs[widget.d].data()['permis'],
                FontAwesomeIcons.idCardAlt),
            item("(+212) " + widget.v.docs[widget.d].data()['prix'],
                FontAwesomeIcons.phoneSquareAlt),
            item(widget.v.docs[widget.d].data()['detailSup'],
                FontAwesomeIcons.fileAlt),
            Divider(
              color: Colors.black,
            ),
            Text("User"),
            Divider(
              color: Colors.black,
            ),
            if (usertrue != null)
              if (user != null && usertrue.admin)
                Row(
                  children: [
                    SizedBox(
                      height: 75.0,
                      width: 190.0,
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor: color,
                          backgroundImage: user.image != null
                              ? NetworkImage(user.image)
                              : null,
                          child: user.image != null
                              ? Container()
                              : Icon(
                                  Icons.person,
                                  color: Colors.white,
                                ),
                          radius: 30,
                        ),
                        subtitle: Text(user.nomeS),
                        title: Text(
                          user.pseudo,
                          style: style.copyWith(fontSize: 18),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 50.0,
                    ),
                    IconButton(
                        color: Colors.green,
                        iconSize: 40.0,
                        onPressed: () {
                          launchWhatsApp();
                        },
                        icon: Icon(FontAwesomeIcons.whatsappSquare)),
                    IconButton(
                        color: Colors.lightBlue,
                        iconSize: 40.0,
                        onPressed: () {
                          launchURL("tel:${user.phone}");
                        },
                        icon: Icon(FontAwesomeIcons.phoneSquareAlt))
                  ],
                ),
            SizedBox(
              height: 10,
            ),
          ],
        ),
      ),
    );
  }

  ListTile item(String title, IconData icon) {
    return ListTile(
      leading: Icon(icon, color: color),
      title: Text(
        title,
        style: style.copyWith(fontSize: 20),
      ),
    );
  }
}

launchURL(String url) async {
  if (await canLaunch(url)) {
    await launch(url);
  } else {
    throw 'Could not launch $url';
  }
}
