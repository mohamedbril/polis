import 'package:black_list_2/model/user.dart';
import 'package:black_list_2/model/vehicule.dart';
import 'package:black_list_2/services/db.dart';
import 'package:black_list_2/utils/constant.dart';
import 'package:black_list_2/utils/slider.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:floating_action_bubble/floating_action_bubble.dart';
import 'package:flutter/material.dart';
import 'package:flutter_open_whatsapp/flutter_open_whatsapp.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:whatsapp_unilink/whatsapp_unilink.dart';

class CarDetail extends StatefulWidget {
  final Vehicule v;
  CarDetail({this.v});

  @override
  _CarDetailState createState() => _CarDetailState();
}

class _CarDetailState extends State<CarDetail> {
  Color color = Colors.green;
  AnimationController _animationController;
  Animation<double> _animation;
  UserM user;
  UserM usertrue;

  final usera = FirebaseAuth.instance.currentUser;

  get getUsert async {
    final u = await DBServices().getUser(usera.uid);
    if (u != null) {
      setState(() {
        usertrue = u;
      });
    }
  }

  getUser() async {
    final u = await DBServices().getUser(widget.v.uid);
    if (u != null) {
      setState(() {
        user = u;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    getUsert;
    getUser();
  }

  @override
  Widget build(BuildContext context) {
    color = widget.v.type == CarType.car ? Colors.green : Colors.lightBlue;
    launchWhatsApp() async {
      final link = WhatsAppUnilink(
        phoneNumber: '+212${user.phone}',
        text:
            "salam \nje veux savoir plus des informations sur: \n${widget.v.marque}\n${widget.v.modele}\n${widget.v.cart}\n${widget.v.prix} ",
      );
      await launch('$link');
    }

    IconData icon = widget.v.type == CarType.car
        ? FontAwesomeIcons.carAlt
        : FontAwesomeIcons.motorcycle;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: color,
        title: Text(widget.v.marque),
      ),
      body: SingleChildScrollView(
        child: Column(children: [
          Sliders(imgs: widget.v.images),
          SizedBox(
            height: 10,
          ),
          item(widget.v.marque, FontAwesomeIcons.addressBook),
          item(widget.v.modele, FontAwesomeIcons.addressBook),
          item(widget.v.cart, FontAwesomeIcons.addressCard),
          item(widget.v.permis, FontAwesomeIcons.idCardAlt),
          item("(+212) " + widget.v.prix, FontAwesomeIcons.phoneSquareAlt),
          item(widget.v.detailSup, FontAwesomeIcons.fileAlt),
          Divider(
            color: Colors.black,
          ),
          Text("User"),
          Divider(
            color: Colors.black,
          ),
          if (usertrue != null)
            if (user != null && usertrue.admin)
              Row(
                children: [
                  SizedBox(
                    height: 75.0,
                    width: 190.0,
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: color,
                        backgroundImage: user.image != null
                            ? NetworkImage(user.image)
                            : null,
                        child: user.image != null
                            ? Container()
                            : Icon(
                                Icons.person,
                                color: Colors.white,
                              ),
                        radius: 30,
                      ),
                      subtitle: Text(user.nomeS),
                      title: Text(
                        user.pseudo,
                        style: style.copyWith(fontSize: 18),
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 50.0,
                  ),
                  IconButton(
                      color: Colors.green,
                      iconSize: 40.0,
                      onPressed: () {
                        launchWhatsApp();
                      },
                      icon: Icon(FontAwesomeIcons.whatsappSquare)),
                  IconButton(
                      color: Colors.lightBlue,
                      iconSize: 40.0,
                      onPressed: () {
                        launchURL("tel:${user.phone}");
                      },
                      icon: Icon(FontAwesomeIcons.phoneSquareAlt))
                ],
              ),
          /* SizedBox(
              height: 10,
            ),*/
        ]),
      ),
    );
  }

  ListTile item(String title, IconData icon) {
    return ListTile(
      leading: Icon(icon, color: color),
      title: Text(
        title,
        style: style.copyWith(fontSize: 20),
      ),
    );
  }
}

launchURL(String url) async {
  if (await canLaunch(url)) {
    await launch(url);
  } else {
    throw 'Could not launch $url';
  }
}
