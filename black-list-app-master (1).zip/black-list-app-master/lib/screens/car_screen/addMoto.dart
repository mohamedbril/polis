import 'dart:io';

import 'package:black_list_2/model/vehicule.dart';
import 'package:black_list_2/services/db.dart';
import 'package:black_list_2/utils/constant.dart';
import 'package:black_list_2/utils/getImage.dart';
import 'package:black_list_2/utils/loading.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class AddMoto extends StatefulWidget {
  @override
  _AddMotoState createState() => _AddMotoState();
}

class _AddMotoState extends State<AddMoto> {
  final key = GlobalKey<FormState>();
  String marque, model, prix, descrition, permis, cart;
  List<File> images = [];

  Vehicule moto = Vehicule();
  void initState() {
    super.initState();
    moto.type = CarType.moto;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Mauvais client"),
          backgroundColor: Colors.lightBlue,
          actions: [Icon(FontAwesomeIcons.userSlash)],
        ),
        body: SingleChildScrollView(
          child: Container(
            padding: EdgeInsets.all(10),
            child: Form(
              key: key,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TextFormField(
                    validator: (e) => e.isEmpty ? "Remplir se champ" : null,
                    onChanged: (e) => marque = e,
                    decoration: InputDecoration(
                        hintText: "Nome",
                        labelText: "Nome",
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10))),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  TextFormField(
                    validator: (e) => e.isEmpty ? "Remplir se champ" : null,
                    onChanged: (e) => model = e,
                    decoration: InputDecoration(
                        hintText: "Prénom",
                        labelText: "Prénom",
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10))),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  TextFormField(
                    validator: (e) => e.isEmpty ? "Remplir se champ" : null,
                    onChanged: (e) => cart = e,
                    decoration: InputDecoration(
                        hintText: "Cart national",
                        labelText: "Cart National",
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10))),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  TextFormField(
                    keyboardType: TextInputType.datetime,
                    validator: (e) => e.isEmpty ? "Remplir se champ" : null,
                    onChanged: (e) => permis = e,
                    decoration: InputDecoration(
                        hintText: "Permis de Conduire",
                        labelText: "Permis",
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10))),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  TextFormField(
                    keyboardType: TextInputType.phone,
                    validator: (e) => e.isEmpty ? "numéro de téléphone" : null,
                    onChanged: (e) => prix = e,
                    decoration: InputDecoration(
                        hintText: "numéro de téléphone",
                        labelText: "Tel",
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10))),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  TextFormField(
                    validator: (e) => e.isEmpty ? "Remplir se champ" : null,
                    onChanged: (e) => descrition = e,
                    maxLines: 5,
                    decoration: InputDecoration(
                        hintText: "Détails supplémentaires",
                        labelText: "Détails",
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10))),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Wrap(
                    children: [
                      for (int i = 0; i < images.length; i++)
                        Container(
                          decoration: BoxDecoration(
                              color: Colors.black.withOpacity(.4)),
                          margin: EdgeInsets.only(right: 5, bottom: 5),
                          height: 70,
                          width: 70,
                          child: Stack(
                            children: [
                              Image.file(
                                images[i],
                                height: 70,
                                width: 70,
                                fit: BoxFit.cover,
                              ),
                              Align(
                                alignment: Alignment.center,
                                child: IconButton(
                                  icon: Icon(
                                    FontAwesomeIcons.minusCircle,
                                    color: Colors.white,
                                  ),
                                  onPressed: () {
                                    setState(() {
                                      images.removeAt(i);
                                    });
                                  },
                                ),
                              )
                            ],
                          ),
                        ),
                      InkWell(
                        onTap: () async {
                          final data = await showModalBottomSheet(
                              context: context,
                              builder: (ctx) {
                                return GetImage();
                              });
                          if (data != null)
                            setState(() {
                              images.add(data);
                            });
                        },
                        child: Container(
                          width: 60,
                          height: 60,
                          color: Colors.lightBlue,
                          child: Icon(
                            FontAwesomeIcons.plusCircle,
                            color: Colors.white,
                          ),
                        ),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width,
                    child: FlatButton(
                      shape: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                      color: Colors.lightBlue,
                      onPressed: () async {
                        if (key.currentState.validate() && images.length > 0) {
                          print(images);
                          loading(context);
                          moto.marque = marque.toLowerCase();
                          moto.modele = model.toLowerCase();
                          moto.prix = prix;
                          moto.ens =
                              marque.toLowerCase() + " " + model.toLowerCase();
                          moto.ens2 =
                              model.toLowerCase() + " " + marque.toLowerCase();
                          moto.cart = cart.toUpperCase();
                          moto.permis = permis;
                          moto.detailSup = descrition;
                          moto.images = [];
                          moto.uid = FirebaseAuth.instance.currentUser.uid;
                          for (var i = 0; i < images.length; i++) {
                            String urlImage = await DBServices()
                                .uploadImage(images[i], path: "motos");
                            if (urlImage != null) moto.images.add(urlImage);
                          }
                          if (images.length == moto.images.length) {
                            bool save = await DBServices().savevehicule(moto);
                            if (save) {
                              Navigator.of(context).pop();
                              Navigator.of(context).pop();
                            }
                            ;
                          }
                        } else {
                          print("veillez remplir tous les champs");
                        }
                      },
                      child: Text("Enregistrer",
                          style: style.copyWith(
                              color: Colors.white, fontSize: 20)),
                    ),
                  )
                ],
              ),
            ),
          ),
        ));
  }
}
