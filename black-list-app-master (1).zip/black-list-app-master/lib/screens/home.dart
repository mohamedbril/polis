import 'package:black_list_2/model/user_state.dart';
import 'package:black_list_2/screens/introduction.dart';
import 'package:black_list_2/screens/menu_tow.dart';
import 'package:black_list_2/screens/search.dart';
import 'package:black_list_2/model/user.dart';
import 'package:black_list_2/model/vehicule.dart';
import 'package:black_list_2/screens/admin/admin.dart';
import 'package:black_list_2/screens/car_screen/addCar.dart';
import 'package:black_list_2/screens/car_screen/addMoto.dart';
import 'package:black_list_2/screens/car_screen/listcar.dart';
import 'package:black_list_2/screens/car_screen/listmoto.dart';
import 'package:black_list_2/screens/menu.dart';
import 'package:black_list_2/services/auth.dart';
import 'package:black_list_2/services/db.dart';
import 'package:black_list_2/utils/constant.dart';
import 'package:black_list_2/utils/slider.dart';
import 'package:black_list_2/utils/user_provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:floating_action_bubble/floating_action_bubble.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage>
    with TickerProviderStateMixin, WidgetsBindingObserver {
  AuthServices auth = AuthServices();
  UserProvider userProvider;
  final DBServices _authMethods = DBServices();
  final key = GlobalKey<ScaffoldState>();
  Animation<double> _animation;
  List imgs;
  AnimationController _animationController;
  User user;
  Future<void> getUser() async {
    final userResult = await auth.user;
    setState(() {
      user = userResult;
    });
  }

  @override
  void initState() {
    super.initState();
    _animationController =
        AnimationController(vsync: this, duration: Duration(microseconds: 250));
    final curve =
        CurvedAnimation(curve: Curves.easeInOut, parent: _animationController);
    _animation = Tween<double>(begin: 0, end: 1).animate(curve);

    WidgetsBinding.instance.addObserver(this);
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      await getUser();
      _authMethods.setUserState(
        userId: user.uid,
        userState: UserState.Online,
      );
    });
  }

  get getCarouselImage async {
    final img = await DBServices().getCarouselImage;
    setState(() {
      imgs = img;
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    getUser();
    String cure = (user.uid != null) ? user.uid : "";

    switch (state) {
      case AppLifecycleState.resumed:
        user.uid != null
            ? _authMethods.setUserState(
                userId: cure, userState: UserState.Online)
            : print("resume state");
        break;
      case AppLifecycleState.inactive:
        user.uid != null
            ? _authMethods.setUserState(
                userId: cure, userState: UserState.Offline)
            : print("inactive state");
        break;
      case AppLifecycleState.paused:
        user.uid != null
            ? _authMethods.setUserState(
                userId: cure, userState: UserState.Waiting)
            : print("paused state");
        break;
      case AppLifecycleState.detached:
        user.uid != null
            ? _authMethods.setUserState(
                userId: cure, userState: UserState.Offline)
            : print("detached state");
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final userm = Provider.of<UserM>(context);
    UserM.currentUser = userm;
    getCarouselImage;

    return Scaffold(
      key: key,
      drawer: NavigationDrawerWidget(),
      appBar: AppBar(
        title: Text("Home"),
        actions: [
          if (userm != null)
            InkWell(
              onTap: () {
                key.currentState.openDrawer();
              },
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 15,
                    backgroundColor: Colors.white,
                    backgroundImage:
                        userm.image != null ? NetworkImage(userm.image) : null,
                    child: userm.image != null
                        ? Container()
                        : Icon(Icons.person, color: Colors.black),
                  ),
                  SizedBox(
                    width: 5,
                  ),
                  Text(userm.pseudo),
                ],
              ),
            ),
          IconButton(
              icon: Icon(
                FontAwesomeIcons.powerOff,
                size: 20,
              ),
              onPressed: () async {
                await mydialog(context, ok: () async {
                  await auth.signOut();
                  setState(() {});
                  Navigator.of(context).push(
                    MaterialPageRoute(builder: (ctx) => Intro()),
                  );
                },
                    title: "Deconnexion",
                    content: "Voulez-vous vous déconnecter?");
              })
        ],
      ),
      body: SingleChildScrollView(
        reverse: false,
        padding: EdgeInsets.all(0),
        child: Column(
          children: [
            Sliders(imgs: imgs),
            Container(
              margin: EdgeInsets.only(top: 10.0),
              padding: EdgeInsets.symmetric(vertical: 40),
              decoration: BoxDecoration(
                border: Border(
                    top: BorderSide(width: 5.0, color: Colors.amber),
                    bottom: BorderSide(width: 5.0, color: Colors.amber)),
              ),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    InkWell(
                      onTap: () {
                        if (userm != null) {
                          if (userm.enable) {
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (ctx) =>
                                    StreamProvider<List<Vehicule>>.value(
                                      value: DBServices()
                                          .getvehicule(type: CarType.car),
                                      child: CarLis(),
                                    )));
                          } else {
                            messages("Votre compte a été bloqué by admin");
                          }
                        }
                      },
                      child: CircleAvatar(
                        radius: 50,
                        backgroundColor: Colors.red,
                        child: Icon(FontAwesomeIcons.userSecret,
                            size: 50, color: Colors.white),
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    InkWell(
                      onTap: () {
                        if (userm != null) {
                          if (userm.enable) {
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (ctx) =>
                                    StreamProvider<List<Vehicule>>.value(
                                  value: DBServices()
                                      .getvehicule(type: CarType.moto),
                                  child: MotoList(),
                                ),
                              ),
                            );
                          } else {
                            messages("Votre compte a été bloqué by admin");
                          }
                        }
                      },
                      child: CircleAvatar(
                        radius: 50,
                        backgroundColor: Colors.orange,
                        child: Icon(FontAwesomeIcons.userSlash,
                            size: 50, color: Colors.white),
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    InkWell(
                      onTap: () {
                        if (userm != null) {
                          if (userm.enable) {
                            Navigator.of(context).push(
                              MaterialPageRoute(builder: (ctx) => SearchPage()),
                            );
                          } else {
                            messages("Votre compte a été bloqué by admin");
                          }
                        }
                      },
                      child: CircleAvatar(
                        radius: 50,
                        backgroundColor: Colors.lightGreen,
                        child: Icon(FontAwesomeIcons.searchengin,
                            size: 60, color: Colors.white),
                      ),
                    )
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionBubble(
        backGroundColor: Colors.lightBlue,
        items: [
          if (userm != null)
            if (userm.admin)
              Bubble(
                  title: "Espace admin afm",
                  titleStyle: style.copyWith(fontSize: 16, color: Colors.white),
                  iconColor: Colors.green[100],
                  bubbleColor: Colors.deepPurpleAccent,
                  icon: FontAwesomeIcons.userShield,
                  onPress: () {
                    _animationController.reverse();
                    Navigator.of(context)
                        .push(MaterialPageRoute(builder: (ctx) => AdminPage()));
                  }),
          Bubble(
              title: "Mauvais client",
              titleStyle: style.copyWith(fontSize: 16, color: Colors.white),
              iconColor: Colors.grey[500],
              bubbleColor: Colors.deepOrangeAccent,
              icon: FontAwesomeIcons.userSlash,
              onPress: () {
                _animationController.reverse();
                if (userm != null) {
                  if (userm.enable) {
                    Navigator.of(context)
                        .push(MaterialPageRoute(builder: (ctx) => AddMoto()));
                  } else {
                    messages("Votre compte a été bloqué");
                  }
                }
              }),
          Bubble(
              title: "Rechercher",
              titleStyle:
                  style.copyWith(fontSize: 16, color: Colors.amber[200]),
              iconColor: Colors.amber,
              bubbleColor: Colors.blueGrey,
              icon: FontAwesomeIcons.search,
              onPress: () {
                _animationController.reverse();
                if (userm != null) {
                  if (userm.enable) {
                    Navigator.of(context).push(
                        MaterialPageRoute(builder: (ctx) => SearchPage()));
                  } else {
                    messages("Votre compte a été bloqué");
                  }
                }
              }),
          Bubble(
              title: "Voleurs",
              titleStyle: style.copyWith(fontSize: 16, color: Colors.white),
              iconColor: Colors.grey[700],
              bubbleColor: Colors.red,
              icon: FontAwesomeIcons.userSecret,
              onPress: () {
                _animationController.reverse();
                if (userm != null) {
                  if (userm.enable) {
                    Navigator.of(context)
                        .push(MaterialPageRoute(builder: (ctx) => AddCar()));
                  } else {
                    messages("Votre compte a été bloqué");
                  }
                }
              })
        ],
        onPress: _animationController.isCompleted
            ? _animationController.reverse
            : _animationController.forward,
        animation: _animation,
        iconColor: Colors.white,
        animatedIconData: AnimatedIcons.add_event,
      ),
    );
  }

  @override
  void dispose() {
    super.dispose();
    WidgetsBinding.instance.removeObserver(this);
  }
}
/*if (user.uid != null) {
      if (state == AppLifecycleState.resumed) {
        _authMethods.setUserState(
            userId: user.uid, userState: UserState.Online);
      }
      if (state == AppLifecycleState.paused) {
        _authMethods.setUserState(
            userId: user.uid, userState: UserState.Waiting);
      }
      if (state == AppLifecycleState.inactive) {
        _authMethods.setUserState(
            userId: user.uid, userState: UserState.Online);
      }
      if (state == AppLifecycleState.detached) {
        _authMethods.setUserState(
            userId: user.uid, userState: UserState.Offline);
      }
    }*/
