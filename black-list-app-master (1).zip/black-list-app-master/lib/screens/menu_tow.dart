import 'package:black_list_2/model/user.dart';
import 'package:black_list_2/model/vehicule.dart';
import 'package:black_list_2/screens/about.dart';
import 'package:black_list_2/screens/car_screen/addMoto.dart';
import 'package:black_list_2/screens/car_screen/favories.dart';
import 'package:black_list_2/screens/car_screen/listcar.dart';
import 'package:black_list_2/screens/car_screen/listmoto.dart';
import 'package:black_list_2/screens/search.dart';
import 'package:black_list_2/services/db.dart';
import 'package:black_list_2/utils/constant.dart';
import 'package:black_list_2/utils/getImage.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

class NavigationDrawerWidget extends StatefulWidget {
  @override
  _NavigationDrawerWidgetState createState() => _NavigationDrawerWidgetState();
}

class _NavigationDrawerWidgetState extends State<NavigationDrawerWidget> {
  final padding = EdgeInsets.symmetric(horizontal: 20);
  bool loading = false;

  @override
  Widget build(BuildContext context) {
    final user = Provider.of<UserM>(context);
    final name = (user.pseudo != null) ? user.pseudo : "";
    final email = (user.nomeS != null) ? user.nomeS : "";
    final urlImage = (user.image != null) ? user.image : "";
    return Drawer(
      child: Material(
        color: Color.fromRGBO(50, 75, 205, 1),
        child: ListView(
          children: <Widget>[
            buildHeader(
              urlImage: urlImage,
              name: name,
              email: email,
              onClicked: () => {},
            ),
            Container(
              padding: padding,
              child: Column(
                children: [
                  const SizedBox(height: 12),
                  buildSearchField(),
                  const SizedBox(height: 24),
                  buildMenuItem(
                    text: 'Favourites',
                    icon: Icons.favorite_border,
                    onClicked: () => selectedItem(context, 2),
                  ),
                  const SizedBox(height: 16),
                  buildMenuItem(
                    text: 'voleurs',
                    icon: FontAwesomeIcons.userSecret,
                    onClicked: () => selectedItem(context, 1),
                  ),
                  const SizedBox(height: 16),
                  buildMenuItem(
                    text: 'Mauvais Client',
                    icon: FontAwesomeIcons.userAltSlash,
                    onClicked: () => selectedItem(context, 0),
                  ),
                  const SizedBox(height: 16),
                  buildMenuItem(
                    text: 'Contact',
                    icon: FontAwesomeIcons.houzz,
                    onClicked: () => selectedItem(context, 4),
                  ),
                  const SizedBox(height: 16),
                  buildMenuItem(
                    text: 'facebook afm',
                    icon: FontAwesomeIcons.facebook,
                    onClicked: () => selectedItem(context, 3),
                  ),
                  const SizedBox(height: 16),
                  buildMenuItem(
                    text: 'Updates',
                    icon: Icons.update,
                    onClicked: () => {},
                  ),
                  const SizedBox(height: 24),
                  Divider(color: Colors.white70),
                  const SizedBox(height: 24),
                  buildMenuItem(
                    text: 'Plugins',
                    icon: Icons.account_tree_outlined,
                    onClicked: () => selectedItem(context, 4),
                  ),
                  const SizedBox(height: 16),
                  buildMenuItem(
                    text: 'Notifications',
                    icon: Icons.notifications_outlined,
                    onClicked: () => selectedItem(context, 5),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildHeader({
    String urlImage,
    String name,
    String email,
    UserM user,
    VoidCallback onClicked,
  }) =>
      InkWell(
          hoverColor: Color.fromRGBO(50, 75, 205, 1),
          child: UserAccountsDrawerHeader(
            accountEmail: Text(email ?? "Aucun"),
            accountName: Text(name ?? "Aucun"),
            currentAccountPicture: CircleAvatar(
                radius: 50,
                backgroundColor: Colors.white,
                backgroundImage:
                    urlImage != null ? NetworkImage(urlImage) : null,
                child: Stack(children: [
                  if (urlImage == null)
                    Center(
                        child: Icon(Icons.person,
                            color: Color.fromRGBO(50, 75, 205, 1))),
                  if (loading)
                    Center(
                        child: CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation<Color>(
                          Color.fromRGBO(50, 75, 205, 1)),
                    )),
                  Positioned(
                    top: 38,
                    left: 13,
                    child: IconButton(
                      icon: Icon(
                        Icons.camera_alt,
                        color: Colors.black,
                      ),
                      onPressed: () async {
                        final data = await showModalBottomSheet(
                            context: context,
                            builder: (ctx) {
                              return GetImage();
                            });
                        if (data != null) {
                          loading = true;
                          setState(() {});
                          String urlImages = await DBServices()
                              .uploadImage(data, path: "profil");
                          final userA = FirebaseAuth.instance.currentUser;

                          final u = await DBServices().getUser(userA.uid);

                          if (urlImages != null) {
                            final updateUser = u;
                            print("is here");
                            updateUser.image = urlImages;
                            bool isupdate =
                                await DBServices().updateUser(updateUser);
                            if (isupdate) {
                              loading = false;
                              setState(() {});
                            }
                          }
                        }
                      },
                    ),
                  )
                ])),
          ));

  Widget buildSearchField() {
    final color = Colors.white;

    return TextField(
      onTap: () {
        Navigator.of(context)
            .push(MaterialPageRoute(builder: (ctx) => SearchPage()));
      },
      style: TextStyle(color: color),
      decoration: InputDecoration(
        contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
        hintText: 'Search',
        hintStyle: TextStyle(color: color),
        prefixIcon: Icon(Icons.search, color: color),
        filled: true,
        fillColor: Colors.white12,
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(5),
          borderSide: BorderSide(color: color.withOpacity(0.7)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(5),
          borderSide: BorderSide(color: color.withOpacity(0.7)),
        ),
      ),
    );
  }

  Widget buildMenuItem({
    String text,
    IconData icon,
    VoidCallback onClicked,
  }) {
    final color = Colors.white;
    final hoverColor = Colors.white70;

    return ListTile(
      leading: Icon(icon, color: color),
      title: Text(text, style: TextStyle(color: color)),
      hoverColor: hoverColor,
      onTap: onClicked,
    );
  }

  void selectedItem(BuildContext context, int index) async {
    Navigator.of(context).pop();
    final user = FirebaseAuth.instance.currentUser;
    UserM usertrue;
    final u = await DBServices().getUser(user.uid);
    if (u != null) {
      setState(() {
        usertrue = u;
      });
    }

    if (usertrue != null) {
      if (usertrue.enable) {
        switch (index) {
          case 0:
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (ctx) => StreamProvider<List<Vehicule>>.value(
                  value: DBServices().getvehicule(type: CarType.moto),
                  child: MotoList(),
                ),
              ),
            );
            break;
          case 1:
            Navigator.of(context).push(MaterialPageRoute(
                builder: (ctx) => StreamProvider<List<Vehicule>>.value(
                      value: DBServices().getvehicule(type: CarType.car),
                      child: CarLis(),
                    )));

            break;
          case 2:
            Navigator.of(context).push(MaterialPageRoute(
                builder: (ctx) => StreamProvider<List<Vehicule>>.value(
                    value: DBServices().getvehiculefav(CarType.car),
                    child: Favories())));
            break;
          case 3:
            launchURL(
                "https://web.facebook.com/association.forteresse.marrakech");
            break;
          case 4:
            Navigator.of(context)
                .push(MaterialPageRoute(builder: (ctx) => AboutPage()));
            break;
        }
      }
    } else {
      messages("Votre compte a été bloqué by admin");
    }
  }
}

launchURL(String url) async {
  if (await canLaunch(url)) {
    await launch(url);
  } else {
    throw 'Could not launch $url';
  }
}
